#import os, sys
#sys.path.insert(0, os.getcwd()) 

from Engine.chat.chat_engine import chat_agent
from Engine.toolkit import ExecutePythonCodeTool
from langchain.memory import ConversationBufferWindowMemory

# chat_agent("Optimize the planning for fast moving SKUs which are critically low.")
chat_history = ConversationBufferWindowMemory(k=2, human_prefix="User", ai_prefix="Agent")
while 1:
    question = input(">>")
    response = chat_agent(question, chat_history=str(chat_history.load_memory_variables({})["history"]))
    print(response)
    chat_history.save_context({"User": question}, {"Agent": response})
