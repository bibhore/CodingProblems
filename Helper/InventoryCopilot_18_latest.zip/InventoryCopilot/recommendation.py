import os
import langchain
from Engine.toolkit import SaveVariableTool, ExecutePythonCodeTool, SQLAgentTool
from Engine.recommender.recommender_engine import recommender_agent
from Engine.tools.sql_client import SQLClient
from langchain.chat_models import ChatOpenAI
from sqlalchemy.engine import URL
from langchain import SQLDatabase
import re
from langchain.cache import InMemoryCache
from langchain.memory import ConversationBufferWindowMemory
import plotly.graph_objs as go
import multiprocessing

class RecommenderAgent:
    #langchain.llm_cache = InMemoryCache()
    #memory_store = {}
    connection_string = "DRIVER={ODBC Driver 17 for SQL Server};SERVER=sql-maxscbi-dev.database.windows.net;DATABASE=inventorypoc;UID=maxsqladmin;PWD=R!1ainbow9!!"
    connection_url = URL.create("mssql+pyodbc", query={"odbc_connect": connection_string})
    # graphOutput = '{"data":[{"alignmentgroup":"True","hovertemplate":"PlantName=Microsoft Ireland Operations\u003cbr\u003eSKUId=%{x}\u003cbr\u003eNetDemand=%{y}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Microsoft Ireland Operations","marker":{"color":"#636efa","pattern":{"shape":""}},"name":"Microsoft Ireland Operations","offsetgroup":"Microsoft Ireland Operations","orientation":"v","showlegend":true,"textposition":"auto","x":["1T4-00004","1T4-00004","1TH-00008","1TH-00008","CZ2-00268"],"xaxis":"x","y":[800.789,800.789,225.628,225.628,63.653],"yaxis":"y","type":"bar"}],"layout":{"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"SKUId"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"NetDemand"}},"legend":{"title":{"text":"PlantName"},"tracegroupgap":0},"title":{"text":"Fast Moving SKUs"},"barmode":"group"}}'
    chat_history = ConversationBufferWindowMemory(k=2, human_prefix="User", ai_prefix="Agent")
    #db = SQLClient.from_uri(connection_url, schema='dw')
    #db = SQLDatabase.from_uri(connection_url, schema='dw')
    db = SQLClient.from_config(schema='dw')

    @classmethod
    def ReturnRecommendations (cls, persona:str = "all"):
        responselist = []
        persona1 = 'Reverse Inventory Planner'
        persona2 = 'Reverse Operations Manager'
        question1  = 'Analyze fast moving SKUs which are critically low and recommend actions'
        question2  = 'Analyze slow moving or obsolete exchange SKUs and recommend what could be liquidated to optimize cost.'
        question3 = 'Analyze SKU demand forecasts and provide recommendation on optimizing the inventory holding cost without running a risk of stock out'
        # chat = ChatOpenAI(
        #     temperature=0.0,
        #     verbose=True,
        #     openai_api_key=os.getenv("OPENAI_API_KEY"),
        #     model_kwargs={'deployment_id': os.getenv("OPENAI_DEPLOYMENT_ENGINE")}
        # )

        input1 = str.format("Persona: {persona}, Scenario: {question}", persona=persona1, question = question1)
        input2 = str.format("Persona: {persona}, Scenario: {question}", persona=persona1, question = question2)
        input3 = str.format("Persona: {persona}, Scenario: {question}", persona=persona2, question = question3)
        if persona == 'all':
                inputs = [input1,input2,input3]
        elif persona == 'planner':
                inputs = [input1,input2]
        elif persona == 'operations':
                inputs = [input3]

        j= 1
        for i in inputs:
            if len(inputs) == 1 : j =3
            answer = recommender_agent(i, cls.db)
            response = answer['response']
            chart = answer['chart']
            response_value = response.split("\n")
            response = {'title':locals()[f'question{j}'], 'detail':response_value, 'chart': chart}
            print(f'Finished {j} ------------------------------------')
            responselist.append(response)
            j = j+1
        # with multiprocessing.Pool(processes=2) as pool:
        #     results = pool.map(recommender_agent, inputs)
        #answer = recommender_agent(input)
        # print (results)
        # return
        # answer1 = recommender_agent(input2)
        # print('Finished one ------------------------------------')
        # answer2 = recommender_agent(input2)
        #answer = ''
       #Persona: Reverse Inventory Planner, Scenario: Find the fast moving SKUs which are critically low.
       #scenario = "Persona: Reverse Inventory Planner, Scenario: Plan to liquidate slow moving or obsolete exchange SKUs"
        #Persona: Reverse Operations Manager, Scenario: Enhance inventory efficiency by assessing SKU demand forecasts and classifying them into Just-in-Time (JIT) or Safety Stock categories.
        #response_pattern = r"ActionableItems:([a-zA-Z0-9 :.\-()[\]',\s\\]*)Chart"
        #response_value = re.search(response_pattern, answer1).group(1)
        # response1 = answer1['response']
        # chart1 = answer1['chart']
        # response_value1.remove("")
        # response_value1 = response1.split("\n")
        # response1 = {'title':question1, 'detail':response_value1, 'chart': chart1}
        
        # response2 = answer2['response']
        # chart2 = answer2['chart']
        # response_value2.remove("")
        # response_value2 = response2.split("\n")
        # response2 = {'title':question2, 'detail':response_value2, 'chart': chart2}
        #'title': 'The inventory of surface laptop 4 is critically low and needs to be replenished, this is a fast moving item.', 'detail': 'The inventory of surface laptop 4 is critically low and needs to be replenished, this is a fast moving item.'
       
        # response = [response1, response2]
        return responselist