from flask import Flask, jsonify, request
import random
from middleware import InMemoryData
import json
from contextquestionchain import ContextualChain
from recommendation import RecommenderAgent
#from flask_cors import CORS   
from cachetools import TTLCache
import os
import chat
import time

app = Flask(__name__)
#CORS(app, resources={r"/*": {"origins": "http://localhost:3000"}})
#cache = TTLCache(maxsize=10, ttl=300000000)
cache = {}
#os.environ["OPENAI_API_VERSION"] = "2023-06-01-preview"
os.environ["OPENAI_API_TYPE"] = "azure"
# os.environ["OPENAI_API_KEY"] = "23546b1af6524614b425f3aba3504b9b"
# os.environ["OPENAI_API_BASE"] = "https://crewaoipoc.openai.azure.com/"
# os.environ["OPENAI_DEPLOYMENT_ENGINE"] = "insights"
# os.environ["OPENAI_EMBEDDING_DEPLOYMENT_ENGINE"] = "text-embedding-ada-002"
os.environ["OPENAI_API_TYPE"]="azure"
os.environ["OPENAI_API_BASE"]="https://scriptazureopenai.openai.azure.com/"
os.environ["OPENAI_API_KEY"]="3e7032c6ac9e4f64847ed831f6e9ad5d"
os.environ["OPENAI_DEPLOYMENT_ENGINE"]="sce-copilot"
os.environ["OPENAI_EMBEDDING_DEPLOYMENT_ENGINE"]="sce-qna"

recommendations = [ {'role': 'operations', 'list': [
                                            {'title': 'Identify slow-moving SKUs in the Exchange category.', 'detail': 'Slow-moving SKUs tie up inventory and can lead to increased costs. By identifying them, the planner can take action to liquidate or move them to free up inventory and reduce costs.'},
                                            {'title': 'Monitor inventory levels of fast-moving SKUs in the Exchange category.', 'detail': 'Fast-moving SKUs are critical to customer satisfaction and need to be available in sufficient quantities. By monitoring inventory levels, the planner can ensure that these SKUs are always in stock.'},
                                            {'title': 'Analyze demand forecasts for the next 12 weeks to identify potential inventory shortages.', 'detail': 'By analyzing demand forecasts, the planner can identify potential inventory shortages and take action to prevent them.'},
                                            {'title': 'Monitor in-transit inventory levels to ensure timely delivery of replacement devices.', 'detail': 'In-transit inventory is critical to fulfilling customer orders. By monitoring in-transit inventory levels, the planner can ensure timely delivery of replacement devices.'}
                    ]}, 
                    {'role': 'planner', 'list': [
                                            {'title': 'The inventory of surface laptop 4 is critically low and needs to be replenished, this is a fast moving item.', 'detail': 'The inventory of surface laptop 4 is critically low and needs to be replenished, this is a fast moving item.'},
                                            {'title': 'The inventory of surface Pro 8 is big and needs to be liquidated, this is a slow moving item.', 'detail': 'The inventory of surface Pro 8 is big and needs to be liquidated, this is a slow moving item.'},
                                            {'title': 'The inventory at IvyTech Poland is very low, you can move some inventory from other plant locations to meet demand.', 'detail': 'The inventory at IvyTech Poland is very low, you can move some inventory from other plant locations to meet demand.'},
                                            {'title': 'Slow moving inventory items with low average weekly quantity shipped need to be liquidated or moved to optimize net inventory cost.', 'detail': 'Slow moving inventory items with low average weekly quantity shipped need to be liquidated or moved to optimize net inventory cost.'},
                                            {'title': 'Fast moving inventory items with high average weekly quantity shipped need to be replenished to meet customer demand and optimize net inventory cost.', 'detail': 'Fast moving inventory items with high average weekly quantity shipped need to be replenished to meet customer demand and optimize net inventory cost.'}                 
                    ]}
                ]



@app.route('/recommendations')
def get_recommendations():
    return_value = []
    data = RecommenderAgent.ReturnRecommendations()
    # for rec in recommendations:
    #     for item in rec['list']:
    #         return_value.append(item)
    return jsonify(data)
    #allrole = 'all'
    #if allrole not in cache:
    #    cache[allrole] = RecommenderAgent.ReturnRecommendations()
    #return jsonify(cache[allrole])

@app.route('/recommendations/<string:role>')
def get_by_role(role):
    if role not in cache:
        data = RecommenderAgent.ReturnRecommendations(role)
        cache[role]=data
    else:
        #time.sleep(2)
        randomDelay = random.randint(1,5)
        time.sleep(randomDelay)
        data = cache[role]
    return jsonify(data)

@app.route('/chat', methods=['POST'])
def post_chat_question():
    ignore_words = ['sorry', 'I don\'t know']
    data = request.get_json()
    question =  data.get('Question')
    scenario = data.get('Scenario')
    persona = data.get('Persona')
    details = data.get('Details')

    if not scenario:
       scenario= 'general'

    history = InMemoryData.get_data(scenario)
    userquestion = question
    
    if len(history) <= 0 and scenario != 'general':
        usercontextquestion = str.format("Persona: {persona}, Scenario: {scenario}", persona=persona, scenario = scenario)
        #aicontextanswer = str(details)
        aicontextanswer = '\n'.join(map(str,details))
        InMemoryData.add_data(scenario,{'User':usercontextquestion,'Agent':aicontextanswer})

    history = InMemoryData.get_data(scenario)
    value = search_key_value('User', userquestion, history)
    if value is not None:
        return value

    #aiquestion = returnSummarizedQuestionUsingChain(question, history)
    airesponse = getAiResponse(userquestion, history)
    #airesponse = 'Chat will be enabled soon for -'+question
    # filter out AI response with no answers
    skip = map((lambda word: word in airesponse ), ignore_words)
    
    if not any(skip) :
     InMemoryData.add_data(scenario,{'User':userquestion,'Agent':airesponse})
    #response = {'response': airesponse}
    return jsonify(airesponse)

def search_key_value(key, value, data):
    for item in data:
        if item[key] == value:
            return item['Agent']
    return None

@app.route('/chat/<string:scenario>')
def getScenerioHistory(scenario):
    if scenario == 'all':
        scenario = 'general'
    history = InMemoryData.get_data(scenario)
    return jsonify(history)

def validate_json(json_data):
    try:
        data = json_data
        if isinstance(data, dict) and len(data) == 2:
            for key, value in data.items():
                if not isinstance(key, str) or not isinstance(value, str):
                    return False
            return True
        else:
            return False
    except ValueError:
        return False
    
def getAiResponse(question, history):
    response = chat.dochat(question, history)
    return response

# def returnSummarizedQuestionUsingChain(question, history):
#     answer = ContextualChain().GetContextualQuestionFromChain(question, history)
#     return answer
    
if __name__ == "__main__":
    app.run()