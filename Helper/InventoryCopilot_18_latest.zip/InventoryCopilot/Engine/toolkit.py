import re
from typing import Any, Optional

from pydantic import Field

from Engine.prompt.grounding.sql_example_bank import SQL_EXAMPLE_BANK
# from Engine.prompt.prompt import FORMAT_INSTRUCTIONS
from Engine.prompt.sql_prompt import SQL_PREFIX, SQL_SUFFIX, FORMAT_INSTRUCTIONS
#from Engine.prompt.sql_prompt import SQL_PREFIX, SQL_SUFFIX
from Engine.chain import create_agent
from Engine.tools.exampleSelector import example_selector
from Engine.tools.python_client import PythonClient
from Engine.tools.sql_client import SQLClient
from langchain.callbacks.manager import AsyncCallbackManagerForToolRun, CallbackManagerForToolRun
from langchain.base_language import BaseLanguageModel
from langchain.tools.base import BaseTool


def sanitize_input(query: str) -> str:
    """Sanitize input to the python REPL.
    Remove whitespace, backtick & python (if llm mistakes python console as terminal)
    Args:
        query: The query to sanitize
    Returns:
        str: The sanitized query
    """
    # Removes `, whitespace & SQL from start
    query = re.sub(r"^(\s|`|')*(?i:SQL|Python)?[\s\r\n]*", "", query)
    # Removes whitespace & ` from end
    query = re.sub(r"(\s|`|')*$", "", query)
    return query


class QuerySQLDBTool(BaseTool):
    db: SQLClient = Field(exclude=True)
    #return_direct = True
    name = "sql_db_query"
    description = """
    Input to this tool is a detailed and correct T-SQL query, output is a result from the database.
    If the query is not correct, an error message will be returned.
    If an error is returned, rewrite the query, check the query, and try again.
    """

    def _run(
            self,
            query: str,
            run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Execute the query, return the results or an error message."""
        return self.db.run_no_throw(sanitize_input(query))

    async def _arun(
            self,
            query: str = "",
            run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        raise NotImplementedError("ListTablesSqlDbTool does not support async")


class ListSQLDBTool(BaseTool):
    db: SQLClient = Field(exclude=True)

    name = "sql_db_info"
    description = """
    Input to this tool is a detailed and correct T-SQL query, output is a result from the database.
    If the query is not correct, an error message will be returned.
    If an error is returned, rewrite the query, check the query, and try again.
    """

    def _run(
            self,
            tables: str,
            run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Execute the query, return the results or an error message."""
        return self.db.get_table_info()

    async def _arun(
            self,
            query: str = "",
            run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        raise NotImplementedError("ListTablesSqlDbTool does not support async")


class SaveVariableTool(BaseTool):
    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        pass

    db: SQLClient = Field(exclude=True)
    python_client: PythonClient = Field(exclude=True)
    memory_store: dict = Field(exclude=True)
    name = "save_output_as_variable"
    description = """
    This tool can be used to save the output of the last SQL query as a pandas dataframe.
    It takes care of data type of the columns while saving the output.
    Input to this tool would be a meaningful variable name that hasn't been used before. 
    The naming convention for the variable is snake-case and ends with _df. For example, inventory_df.
    It returns 'Success' if the variable is successfully saved. Otherwise, it returns 'Failure'.
    If you receive 'Failure' as output, it means that the variable name is already used. 
    Please use a different variable name.
    """

    def _run(
            self,
            action_input: str,
            run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        try:
            action, variable_name = action_input.split(",")
            action = action.strip()
            variable_name = variable_name.strip()
            if action == "sql_agent":
                self.memory_store[variable_name] = self.db.dataframe
            elif action == "python_plot":
                self.memory_store[variable_name] = self.python_client.last_output
            else:
                raise Exception("Invalid action - " + action)
        except Exception as e:
            return "Failure - " + str(e)
        return "Success"


class ExecutePythonCodeTool(BaseTool):
    name = "python_plot"
    description = """
    Input to this tool is a summary of the code to be generated, output is the generated code.
    This tool is used to generate code for the user that helps them perform analysis and generate charts on the data.
    """

    python_client: PythonClient = Field(exclude=True)
    memory_store: dict = Field(exclude=True)

    async def _arun(
            self,
            tool_input: str = "",
            run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        raise NotImplementedError("ListTablesSqlDbTool does not support async")

    def _run(
            self,
            query: str,
            run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        self.python_client.globals = self.memory_store
        return self.python_client.run(sanitize_input(query))


class SQLAgentTool(BaseTool):
    name = "sql_agent"
    description = """
    """
    db: SQLClient = Field(exclude=True)
    llm: BaseLanguageModel = Field(exclude=True)

    async def _arun(
            self,
            tool_input: str = "",
            run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        raise NotImplementedError("ListTablesSqlDbTool does not support async")

    def _run(
            self,
            query: str,
            run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        tools = [QuerySQLDBTool(db=self.db), ListSQLDBTool(db=self.db)]
        examples = example_selector(SQL_EXAMPLE_BANK, query, 1)
        executor = create_agent(
            self.llm,
            tools,
            prefix=SQL_PREFIX,
            suffix=SQL_SUFFIX,
            examples=examples,
            format_instructions=FORMAT_INSTRUCTIONS,
            template_format="jinja2",
            verbose=True
        )
        return executor.run(query)
