import os
from typing import Optional

from Engine.prompt.recommender_prompt import FORMAT_INSTRUCTIONS
from Engine.tools.exampleSelector import example_selector
from Engine.prompt.grounding.chat_example_bank import CHAT_EXAMPLE_BANK
from Engine.prompt.chat_prompt import CHAT_PREFIX, CHAT_SUFFIX
from Engine.toolkit import SaveVariableTool, ExecutePythonCodeTool, SQLAgentTool
from Engine.chain import create_agent
from Engine.tools.python_client import PythonClient
from Engine.tools.sql_client import SQLClient
from langchain.chat_models import ChatOpenAI
import re

db = SQLClient.from_config(schema='dw')

def chat_agent(question: str, example_count: int = 2, chat_history: Optional[str] = None):
    chat = ChatOpenAI(
        temperature=0.0,
        verbose=True,
        openai_api_key=os.getenv("OPENAI_API_KEY"),
        model_kwargs={'deployment_id': os.getenv("OPENAI_DEPLOYMENT_ENGINE")},
        request_timeout=30
    )
    memory_store = {}
    python_client = PythonClient(_globals=memory_store)
    tools = [
        SaveVariableTool(python_client=python_client, db=db, memory_store=memory_store),
        ExecutePythonCodeTool(python_client=python_client, memory_store=memory_store),
        SQLAgentTool(db=db, llm=chat)
    ]
    # Get the examples list using example selector
    examples = example_selector(CHAT_EXAMPLE_BANK, question, k=example_count, question_key="question")
    executor = create_agent(
        chat,
        tools,
        verbose=True,
        prefix=CHAT_PREFIX,
        suffix=CHAT_SUFFIX,
        examples=examples,
        format_instructions=FORMAT_INSTRUCTIONS,
        template_format="jinja2",
        input_variables=["input", "agent_scratchpad", "chat_history"]
    )

    return {

        "message": executor.run(input=question, chat_history=chat_history).replace("\n","<br/>"),
        "chart": memory_store.get("chart", None)
    }
