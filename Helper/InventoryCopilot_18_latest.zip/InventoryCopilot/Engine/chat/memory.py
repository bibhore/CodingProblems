import os

from langchain import PromptTemplate, LLMChain
from langchain.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferWindowMemory
from langchain.schema import BaseLanguageModel

chat = ChatOpenAI(
    temperature=0.0,
    verbose=True,
    openai_api_key=os.getenv("OPENAI_API_KEY"),
    model_kwargs={'deployment_id': os.getenv("OPENAI_DEPLOYMENT_ENGINE")}
)
memory = ConversationBufferWindowMemory(k=2, human_prefix="User", ai_prefix="Agent")
prompt_template = """
You are a conversational agent that can answer any questions given the chat history so far along with the user question.
ChatHistory:
{chat_history}

Question:
{question}
"""


def get_response(llm: BaseLanguageModel, chat_history: str, question: str) -> str:
    """Get response from language model."""
    # Get response from language model.
    print(chat_history)
    prompt = PromptTemplate(input_variables=["chat_history", "question"], template=prompt_template)
    chain = LLMChain(llm=llm, prompt=prompt)
    return chain.run(chat_history=chat_history, question=question)


while 1:
    question = input(">>")
    print(question)
    response = get_response(chat, str(memory.load_memory_variables({})["history"]), question)
    print(response)
    memory.save_context({"input": question}, {"output": response})
