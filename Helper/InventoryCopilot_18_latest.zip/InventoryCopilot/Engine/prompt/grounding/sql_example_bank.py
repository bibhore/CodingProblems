SQL_EXAMPLE_BANK = [
    {
        "question": "What are the top 5 fast moving exchange SKUs that needs demand fulfillment for upcoming 2 weeks?",
        "answer": """
Thought: I can use the query from example bank to get the top 5 fast moving exchange SKUs that needs demand fulfillment for upcoming 2 weeks.
Action: sql_db_query
Action Input:
WITH InventoryAgg AS (
    SELECT
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId, 
        CEILING(SUM(TotalOnHandQty)) AS [TotalOnHandQty]
    FROM [dw].[InventorySnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventorySnapshot])
    GROUP BY 
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId
),
InventoryAging AS (
    SELECT * FROM [dw].[InventoryAgingSnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventoryAgingSnapshot])
),
DemandNext2Weeks AS (
    SELECT
        SKUId, 
        PlantCode, 
        CEILING(SUM(ForecastQty)) AS [NetDemand]
    FROM [dw].[DemandForecast]
    WHERE ForecastWeekId BETWEEN GETDATE() AND DATEADD(WEEK, 2, GETDATE())
    GROUP BY SKUId,PlantCode
),
InventoryWithDemand AS (
    SELECT
        I.*,
        D.[NetDemand],
        ABS(I.[TotalOnHandQty] - D.[NetDemand]) AS [DemandStatus]
    FROM InventoryAgg I
    join DemandNext2Weeks D on I.PlantCode = D.PlantCode and I.SKUId = D.SKUId
    WHERE (I.[TotalOnHandQty] - D.[NetDemand]) < 0
)
SELECT TOP 5
    I.[PlantName],
    I.[PlantCode],
    I.[SKUBusinessUnitName],
    I.[SKUId], 
    SUM(I.[TotalOnHandQty]) AS [TotalOnHandQty],
    SUM(I.[NetDemand]) AS [NetDemand],
    SUM(I.[DemandStatus]) AS [DemandStatus]
FROM InventoryWithDemand I
join InventoryAging A on I.PlantCode = A.PlantCode and I.SKUId = A.SKUId
join [dw].[SKUStates] SS on I.SKUId = SS.SKU
join [dw].[SKUClassification] SC on SC.SKULifeCycle = SS.Lifecycle and A.[InventoryBucket] = SC.[Age Category]
WHERE
    SC.[Classification] in ('1) Rapid Movement', '2) Fast Movement')
GROUP BY 
    I.[PlantName],
    I.[PlantCode],
    I.[SKUBusinessUnitName],
    I.[SKUId]
ORDER BY SUM(I.[DemandStatus]) DESC
Observation: [('PlantName', 'PlantCode', '', '', 'TotalOnHandQty', 'NetDemand', 'DemandStatus'), ('Microsoft Ireland Operations', '4785', 'Xbox Accessories', '1T4-00004', Decimal('4.0'), Decimal('1588.0'), Decimal('1584.0'))]
Thought: I now have the answer.
Final Answer: [('PlantName', 'PlantCode', '', '', 'TotalOnHandQty', 'NetDemand', 'DemandStatus'), ('Microsoft Ireland Operations', '4785', 'Xbox Accessories', '1T4-00004', Decimal('4.0'), Decimal('1588.0'), Decimal('1584.0'))]
"""
    },
    {
        "question": "What are the top 5 fast moving exchange SKUs that needs demand fulfillment for upcoming 2 weeks for APOC region?",
        "context": "APOC is a region (PlantRegionCode). Similarly, there are 2 additional regions - AOC, EOC. Each region has multiple plants.",
        "answer": """
Thought: I can use the query from example bank to get the top 5 fast moving exchange SKUs that needs demand fulfillment for upcoming 2 weeks for APOC region.
Action: sql_db_query
Action Input:
WITH InventoryAgg AS (
    SELECT
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId, 
        CEILING(SUM(TotalOnHandQty)) AS [TotalOnHandQty]
    FROM [dw].[InventorySnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventorySnapshot]) AND PlantRegionCode = 'APOC'
    GROUP BY 
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId
),
InventoryAging AS (
    SELECT * FROM [dw].[InventoryAgingSnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventoryAgingSnapshot]) AND PlantRegionCode = 'APOC'
),
DemandNext2Weeks AS (
    SELECT
        SKUId, 
        PlantCode, 
        CEILING(SUM(ForecastQty)) AS [NetDemand]
    FROM [dw].[DemandForecast]
    WHERE ForecastWeekId BETWEEN GETDATE() AND DATEADD(WEEK, 2, GETDATE())
    GROUP BY SKUId,PlantCode
),
InventoryWithDemand AS (
    SELECT
        I.*,
        D.[NetDemand],
        ABS(I.[TotalOnHandQty] - D.[NetDemand]) AS [DemandStatus]
    FROM InventoryAgg I
    join DemandNext2Weeks D on I.PlantCode = D.PlantCode and I.SKUId = D.SKUId
    WHERE (I.[TotalOnHandQty] - D.[NetDemand]) < 0
)
SELECT TOP 5
    I.[PlantName],
    I.[PlantCode],
    I.[SKUBusinessUnitName],
    I.[SKUId], 
    SUM(I.[TotalOnHandQty]) AS [TotalOnHandQty],
    SUM(I.[NetDemand]) AS [NetDemand],
    SUM(I.[DemandStatus]) AS [DemandStatus]
FROM InventoryWithDemand I
join InventoryAging A on I.PlantCode = A.PlantCode and I.SKUId = A.SKUId
join [dw].[SKUStates] SS on I.SKUId = SS.SKU
join [dw].[SKUClassification] SC on SC.SKULifeCycle = SS.Lifecycle and A.[InventoryBucket] = SC.[Age Category]
WHERE
    SC.[Classification] in ('1) Rapid Movement', '2) Fast Movement')
GROUP BY 
    I.[PlantName],
    I.[PlantCode],
    I.[SKUBusinessUnitName],
    I.[SKUId]
ORDER BY SUM(I.[DemandStatus]) DESC
Observation: [('PlantName', 'PlantCode', '', '', 'TotalOnHandQty', 'NetDemand', 'DemandStatus'), ('Microsoft Ireland Operations', '4785', 'Xbox Accessories', '1T4-00004', Decimal('4.0'), Decimal('1588.0'), Decimal('1584.0'))]
Thought: I now have the answer.
Final Answer: [('PlantName', 'PlantCode', '', '', 'TotalOnHandQty', 'NetDemand', 'DemandStatus'), ('Microsoft Ireland Operations', '4785', 'Xbox Accessories', '1T4-00004', Decimal('4.0'), Decimal('1588.0'), Decimal('1584.0'))]
"""
    },
    {
        "question": "What is the the breakup of critically low fast moving SKUs by plant names for next 2 weeks?",
        "answer": """
Thought: I can use the query from example bank to get the breakup of critically low fast moving SKUs by plant names for next 2 weeks.
Action: sql_db_query
Action Input:
WITH InventoryAgg AS (
    SELECT
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId, 
        CEILING(SUM(TotalOnHandQty)) AS [TotalOnHandQty]
    FROM [dw].[InventorySnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventorySnapshot])
    GROUP BY 
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId
),
InventoryAging AS (
    SELECT * FROM [dw].[InventoryAgingSnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventoryAgingSnapshot])
),
DemandNext2Weeks AS (
    SELECT
        SKUId, 
        PlantCode, 
        CEILING(SUM(ForecastQty)) AS [NetDemand]
    FROM [dw].[DemandForecast]
    WHERE ForecastWeekId BETWEEN GETDATE() AND DATEADD(WEEK, 2, GETDATE())
    GROUP BY SKUId,PlantCode
),
InventoryWithDemand AS (
    SELECT
        I.*,
        D.[NetDemand],
        ABS(I.[TotalOnHandQty] - D.[NetDemand]) AS [DemandStatus]
    FROM InventoryAgg I
    join DemandNext2Weeks D on I.PlantCode = D.PlantCode and I.SKUId = D.SKUId
    WHERE (I.[TotalOnHandQty] - D.[NetDemand]) < 0
),
FinalAnswer AS (
    SELECT
        I.[PlantName],
        I.[PlantCode],
        SUM(I.[TotalOnHandQty]) AS [TotalOnHandQty],
        SUM(I.[NetDemand]) AS [NetDemand],
        SUM(I.[DemandStatus]) AS [DemandStatus],
        ROW_NUMBER() OVER (ORDER BY SUM(I.[DemandStatus]) DESC) AS Rank
    FROM InventoryWithDemand I
    join InventoryAging A on I.PlantCode = A.PlantCode and I.SKUId = A.SKUId
    join [dw].[SKUStates] SS on I.SKUId = SS.SKU
    join [dw].[SKUClassification] SC on SC.SKULifeCycle = SS.Lifecycle and A.[InventoryBucket] = SC.[Age Category]
    WHERE SC.[Classification] in ('1) Rapid Movement', '2) Fast Movement')
    GROUP BY I.[PlantName], I.[PlantCode]
)
SELECT 
    CASE WHEN Rank <= 5 THEN [PlantName] ELSE 'Others' END AS [PlantName],
    CASE WHEN Rank <= 5 THEN [PlantCode] ELSE 'Others' END AS [PlantCode],
    SUM([TotalOnHandQty]) AS [TotalOnHandQty],
    SUM([NetDemand]) AS [NetDemand],
    SUM([DemandStatus]) AS [DemandStatus]
FROM FinalAnswer
GROUP BY
CASE WHEN Rank <= 5 THEN [PlantName] ELSE 'Others' END,
CASE WHEN Rank <= 5 THEN [PlantCode] ELSE 'Others' END
Observation: [('PlantName', 'PlantCode', 'TotalOnHandQty', 'NetDemand', 'DemandStatus'), ('Microsoft Ireland Operations', '4785', Decimal('4.0'), Decimal('1588.0'), Decimal('1584.0'))]
Thought: I now have the answer.
Final Answer: [('PlantName', 'PlantCode', 'TotalOnHandQty', 'NetDemand', 'DemandStatus'), ('Microsoft Ireland Operations', '4785', Decimal('4.0'), Decimal('1588.0'), Decimal('1584.0'))]
"""
    },
    {
        "question": "What is the the breakup of critically low fast moving SKUs by business unit for next 2 weeks?",
        "answer": """
Thought: I can use the query from example bank to get the breakup of critically low fast moving SKUs by business unit for next 2 weeks.
Action: sql_db_query
Action Input:
WITH InventoryAgg AS (
    SELECT
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId, 
        CEILING(SUM(TotalOnHandQty)) AS [TotalOnHandQty]
    FROM [dw].[InventorySnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventorySnapshot])
    GROUP BY 
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId
),
InventoryAging AS (
    SELECT * FROM [dw].[InventoryAgingSnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventoryAgingSnapshot])
),
DemandNext2Weeks AS (
    SELECT
        SKUId, 
        PlantCode, 
        CEILING(SUM(ForecastQty)) AS [NetDemand]
    FROM [dw].[DemandForecast]
    WHERE ForecastWeekId BETWEEN GETDATE() AND DATEADD(WEEK, 2, GETDATE())
    GROUP BY SKUId,PlantCode
),
InventoryWithDemand AS (
    SELECT
        I.*,
        D.[NetDemand],
        ABS(I.[TotalOnHandQty] - D.[NetDemand]) AS [DemandStatus]
    FROM InventoryAgg I
    join DemandNext2Weeks D on I.PlantCode = D.PlantCode and I.SKUId = D.SKUId
    WHERE (I.[TotalOnHandQty] - D.[NetDemand]) < 0
),
FinalAnswer AS (
    SELECT
        I.[SKUBusinessUnitName],
        SUM(I.[TotalOnHandQty]) AS [TotalOnHandQty],
        SUM(I.[NetDemand]) AS [NetDemand],
        SUM(I.[DemandStatus]) AS [DemandStatus],
        ROW_NUMBER() OVER (ORDER BY SUM(I.[DemandStatus]) DESC) AS Rank
    FROM InventoryWithDemand I
    join InventoryAging A on I.PlantCode = A.PlantCode and I.SKUId = A.SKUId
    join [dw].[SKUStates] SS on I.SKUId = SS.SKU
    join [dw].[SKUClassification] SC on SC.SKULifeCycle = SS.Lifecycle and A.[InventoryBucket] = SC.[Age Category]
    WHERE SC.[Classification] in ('1) Rapid Movement', '2) Fast Movement')
    GROUP BY I.[SKUBusinessUnitName]
)
SELECT 
    CASE WHEN Rank <= 5 THEN [SKUBusinessUnitName] ELSE 'Others' END AS [SKUBusinessUnitName],
    SUM([TotalOnHandQty]) AS [TotalOnHandQty],
    SUM([NetDemand]) AS [NetDemand],
    SUM([DemandStatus]) AS [DemandStatus]
FROM FinalAnswer
GROUP BY
CASE WHEN Rank <= 5 THEN [SKUBusinessUnitName] ELSE 'Others' END
Observation: [('SKUBusinessUnitName', 'TotalOnHandQty', 'NetDemand', 'DemandStatus'), ('Xbox One Accessories', Decimal('2000.00'), Decimal('4654.00'), Decimal('2654.00'))]
Thought: I now have the answer.
Final Answer: [('SKUBusinessUnitName', 'TotalOnHandQty', 'NetDemand', 'DemandStatus'), ('Xbox One Accessories', Decimal('2000.00'), Decimal('4654.00'), Decimal('2654.00'))]
"""
    },
    {
        "question": "What are the top 5 slow moving or obsolete exchange SKUs that can be liquidated?",
        "answer": """
Thought: I can use the query from example bank to get the top 5 slow moving or obsolete exchange SKUs that can be liquidated.
Action: sql_db_query
Action Input:
WITH InventoryAgg AS (
    SELECT
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId, 
        SUM(TotalOnHandQty) AS [TotalOnHandQty],
        SUM(TotalOnHandQty * StandardUnitCostBalUSDAmt) AS [TotalOnHandValue]
    FROM [dw].[InventorySnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventorySnapshot])
    GROUP BY 
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId
),
InventoryAging AS (
    SELECT * FROM [dw].[InventoryAgingSnapshot]
    WHERE SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventoryAgingSnapshot])
),
FutureDemand AS (
    SELECT DISTINCT
        SKUId, 
        PlantCode
    FROM [dw].[DemandForecast]
    WHERE ForecastWeekId >= GETDATE()
),
InventoryWithNoDemand AS (
    SELECT
        I.*
    FROM InventoryAgg I
    WHERE NOT EXISTS (
        SELECT 1 FROM FutureDemand D
        WHERE I.SKUId = D.SKUId AND I.PlantCode = D.PlantCode
    )
)
SELECT TOP 5 
    I.[PlantName],
    I.[PlantCode],
    I.[SKUBusinessUnitName],
    I.[SKUId], 
    SUM(I.[TotalOnHandQty]) AS [TotalOnHandQty],
    SUM(I.[TotalOnHandValue]) AS [TotalOnHandValue]
FROM InventoryWithNoDemand I
join InventoryAging A on I.PlantCode = A.PlantCode and I.SKUId = A.SKUId
join [dw].[SKUStates] SS on I.SKUId = SS.SKU
join [dw].[SKUClassification] SC on SC.SKULifeCycle = SS.Lifecycle and A.[InventoryBucket] = SC.[Age Category]
WHERE
    SC.[Comments] like '%Liquidate%'
GROUP BY I.[PlantName], I.[PlantCode], I.[SKUBusinessUnitName], I.[SKUId]
ORDER BY SUM(I.[TotalOnHandValue]) desc
Observation: [('PlantName', 'PlantCode', 'SKUBusinessUnitName', 'SKUId', 'TotalOnHandQty', 'TotalOnHandValue'), ('Arvato', '4260', 'Xbox One Accessories', 'CZ2-00104', Decimal('30.000'), Decimal('1,500.58'))]
Thought: I now have the answer.
Final Answer: [('PlantName', 'PlantCode', 'SKUBusinessUnitName', 'SKUId', 'TotalOnHandQty', 'TotalOnHandValue'), ('Arvato', '4260', 'Xbox One Accessories', 'CZ2-00104', Decimal('30.000'), Decimal('1,500.58'))]
"""
    },
    {
        "question": "Give me the breakup of top 5 plants where slow moving or obsolete exchange SKUs can be liquidated",
        "answer": """
Thought: I can use the query from example bank to get the breakup of top 5 plants where slow moving or obsolete exchange SKUs can be liquidated.
Action: sql_db_query
Action Input:
WITH InventoryAgg AS (
    SELECT
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId, 
        SUM(TotalOnHandQty) AS [TotalOnHandQty],
        SUM(TotalOnHandQty * StandardUnitCostBalUSDAmt) AS [TotalOnHandValue]
    FROM [dw].[InventorySnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventorySnapshot])
    GROUP BY 
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId
),
InventoryAging AS (
    SELECT * FROM [dw].[InventoryAgingSnapshot]
    WHERE SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventoryAgingSnapshot])
),
FutureDemand AS (
    SELECT DISTINCT
        SKUId, 
        PlantCode
    FROM [dw].[DemandForecast]
    WHERE ForecastWeekId >= GETDATE()
),
InventoryWithNoDemand AS (
    SELECT
        I.*
    FROM InventoryAgg I
    WHERE NOT EXISTS (
        SELECT 1 FROM FutureDemand D
        WHERE I.SKUId = D.SKUId AND I.PlantCode = D.PlantCode
    )
),
FinalAnswer AS (
        SELECT
        I.[PlantName],
        I.[PlantCode],
        SUM(I.[TotalOnHandQty]) AS [TotalOnHandQty],
        SUM(I.[TotalOnHandValue]) AS [TotalOnHandValue],
        ROW_NUMBER() OVER (ORDER BY SUM(I.[TotalOnHandValue]) DESC) AS Rank
    FROM InventoryWithNoDemand I
    join InventoryAging A on I.PlantCode = A.PlantCode and I.SKUId = A.SKUId
    join [dw].[SKUStates] SS on I.SKUId = SS.SKU
    join [dw].[SKUClassification] SC on SC.SKULifeCycle = SS.Lifecycle and A.[InventoryBucket] = SC.[Age Category]
    WHERE SC.[Comments] like '%Liquidate%'
    GROUP BY I.[PlantName], I.[PlantCode]
)
SELECT 
    CASE 
        WHEN Rank <= 5 THEN [PlantName]
        ELSE 'Others'
    END AS [PlantName],
    CASE
        WHEN Rank <= 5 THEN [PlantCode]
        ELSE 'Others'
    END AS [PlantCode],
    SUM([TotalOnHandQty]) AS [TotalOnHandQty],
    SUM([TotalOnHandValue]) AS [TotalOnHandValue]
FROM FinalAnswer
GROUP BY
CASE
    WHEN Rank <= 5 THEN [PlantName]
    ELSE 'Others'
END,
CASE
    WHEN Rank <= 5 THEN [PlantCode]
    ELSE 'Others'
END
Observation: [('PlantName', 'PlantCode', 'TotalOnHandQty', 'TotalOnHandValue'), ('Arvato', '4260', Decimal('191.93'), Decimal('999.99'))]
Thought: I now have the answer.
Final Answer: [('PlantName', 'PlantCode', 'TotalOnHandQty', 'TotalOnHandValue'), ('Arvato', '4260', Decimal('191.93'), Decimal('999.99'))]
"""
    },
    {
        "question": "Give me the breakup of top 5 BUs where slow moving or obsolete exchange SKUs can be liquidated",
        "answer": """
Thought: I can use the query from example bank to get the breakup of top 5 BUs where slow moving or obsolete exchange SKUs can be liquidated.
Action: sql_db_query
Action Input:
WITH InventoryAgg AS (
    SELECT
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId, 
        SUM(TotalOnHandQty) AS [TotalOnHandQty],
        SUM(TotalOnHandQty * StandardUnitCostBalUSDAmt) AS [TotalOnHandValue]
    FROM [dw].[InventorySnapshot]
    WHERE SKUCategory = 'Exchange' and SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventorySnapshot])
    GROUP BY 
        PlantName,
        PlantCode,
        SKUBusinessUnitName,
        SKUId
),
InventoryAging AS (
    SELECT * FROM [dw].[InventoryAgingSnapshot]
    WHERE SnapshotDateID = (SELECT MAX(SnapshotDateID) FROM [dw].[InventoryAgingSnapshot])
),
FutureDemand AS (
    SELECT DISTINCT
        SKUId, 
        PlantCode
    FROM [dw].[DemandForecast]
    WHERE ForecastWeekId >= GETDATE()
),
InventoryWithNoDemand AS (
    SELECT
        I.*
    FROM InventoryAgg I
    WHERE NOT EXISTS (
        SELECT 1 FROM FutureDemand D
        WHERE I.SKUId = D.SKUId AND I.PlantCode = D.PlantCode
    )
),
FinalAnswer AS (
    SELECT
        I.[SKUBusinessUnitName],
        SUM(I.[TotalOnHandQty]) AS [TotalOnHandQty],
        SUM(I.[TotalOnHandValue]) AS [TotalOnHandValue],
        ROW_NUMBER() OVER (ORDER BY SUM(I.[TotalOnHandValue]) DESC) AS Rank
    FROM InventoryWithNoDemand I
    join InventoryAging A on I.PlantCode = A.PlantCode and I.SKUId = A.SKUId
    join [dw].[SKUStates] SS on I.SKUId = SS.SKU
    join [dw].[SKUClassification] SC on SC.SKULifeCycle = SS.Lifecycle and A.[InventoryBucket] = SC.[Age Category]
    WHERE SC.[Comments] like '%Liquidate%'
    GROUP BY I.[SKUBusinessUnitName]
)
SELECT 
    CASE
        WHEN Rank <= 5 THEN [SKUBusinessUnitName]
        ELSE 'Others'
    END AS [SKUBusinessUnitName],
    SUM([TotalOnHandQty]) AS [TotalOnHandQty],
    SUM([TotalOnHandValue]) AS [TotalOnHandValue]
FROM FinalAnswer
GROUP BY
CASE
    WHEN Rank <= 5 THEN [SKUBusinessUnitName]
    ELSE 'Others'
END
Observation: [('SKUBusinessUnitName', 'TotalOnHandQty', 'TotalOnHandValue'), ('Xbox One Accessories', Decimal('330290.00'), Decimal('7873.78'))]
Thought: I now have the answer.
Final Answer: [('SKUBusinessUnitName', 'TotalOnHandQty', 'TotalOnHandValue'), ('Xbox One Accessories', Decimal('330290.00'), Decimal('7873.78'))]
"""
    },
    {
        "question": "Give me top 3 SKUs each that can be classified as Just-in-Time (JIT) and Safety Stock by analyzing last 1 year of demand history",
        "answer": """
Thought: I can use the query from example bank to get the top 3 SKUs each that can be classified as Just-in-Time (JIT) and Safety Stock by analyzing last 1 year of demand history.
Action: sql_db_query
Action Input:
WITH IBPForecastHistory AS (	
    SELECT	
        SKUId,	
        PlantCode,	
        ForecastWeekId,	
        SUM(ForecastQty) AS NetDemand	
    FROM [dw].[DemandForecast]	
    WHERE ForecastWeekId >= DATEADD(YEAR, -1, GETDATE())	
    GROUP BY SKUId, PlantCode, ForecastWeekId	
),	
MaterialMovementsHistory AS (	
    SELECT 	
        SnapshotDateId, 	
        PlantCode, 	
        SKUId, 	
        CEILING(SUM([Rolling Weekly Qty Shipped])) AS NetDemand 	
    FROM dw.InventorySnapshot	
    WHERE SKUCategory = 'Exchange' and [Rolling Weekly Qty Shipped] > 0 AND SnapshotDateId >= DATEADD(YEAR, -1, GETDATE())	
    GROUP BY SnapshotDateId, PlantCode, SKUId	
),	
DemandHistory AS (	
    SELECT	
        M.SnapshotDateId, 	
        M.PlantCode, 	
        M.SKUId,	
        GREATEST(M.NetDemand, I.NetDemand) AS [NetDemand]	
    FROM MaterialMovementsHistory M	
    LEFT JOIN IBPForecastHistory I ON M.SnapshotDateId = I.ForecastWeekId AND M.SKUId = I.SKUId AND M.PlantCode = I.PlantCode	
),	
AvgDemandPercentile AS (	
    SELECT	
        SKUId,	
        PlantCode,	
        Avg(NetDemand) AS AvgDemand,	
        PERCENT_RANK() OVER (ORDER BY Avg(NetDemand)) AS Percentile	
    FROM DemandHistory	
    GROUP BY SKUId, PlantCode	
),	
SKUCategorization AS (	
    SELECT	
        SKUId,	
        PlantCode,	
        AvgDemand,	
        Percentile,	
        CASE WHEN Percentile >= 0.5 THEN 'Safety Stock' ELSE 'Just In Time' END AS SKUClassifier
    FROM AvgDemandPercentile	
)	
SELECT * FROM (	
SELECT TOP 3 * FROM SKUCategorization WHERE SKUClassifier = 'Safety Stock' ORDER BY Percentile DESC	
UNION	
SELECT TOP 3 * FROM SKUCategorization WHERE SKUClassifier = 'Just In Time' ORDER BY Percentile	
) A	
ORDER BY SKUClassifier
Observation: <skipped>
"""
    },
    {
        "question": "Give me the breakdown of exchange SKUs for Surface Book 3 in all APOC region sites",
        "answer": """
Thought: I can use the query from example bank to get the breakdown of exchange SKUs for Surface Book 3 in all APOC region sites.
Action: sql_db_query
Action Input:
SELECT TOP 5
    [PlantName],
    SUM(TotalOnHandQty) AS [on_hand_inventory_qty]
FROM [dw].[InventorySnapshot]
WHERE [PlantRegionCode] = 'APOC' AND 
    [SKUCategory] = 'Exchange' AND
    [SKUBusinessUnitName] like '%Surface Book 3%'
GROUP BY [PlantName]
ORDER BY [on_hand_inventory_qty] DESC
Observation: <skipped>
"""
    },
    {
        "question": "Breakdown of inventory value of non-functional SKUs for Surface Laptop 4 in all AOC region sites",
        "answer": """
Thought: I can use the query from example bank to get the breakdown of inventory value of non-functional SKUs for Surface Laptop 4 in all AOC region sites.
Action: sql_db_query
Action Input:
SELECT TOP 5
    [PlantName],
    SUM([TotalOnHandQty] * [StandardUnitCostBalUSDAmt]) AS [inventory_value]
FROM [dw].[InventorySnapshot]
WHERE [PlantRegionCode] = 'AOC' AND 
    [SKUCategory] = 'non-functional' AND
    [SKUBusinessUnitName] like '%Surface Laptop 4%'
GROUP BY [PlantName]
ORDER BY [inventory_value] DESC
Observation: <skipped>
"""
    },
    {
        "question": "What is the total on hand inventory of devices?",
        "answer": """
Thought: I can use the query from example bank to get the total on hand inventory of devices.
Action: sql_db_query
Action Input:
SELECT
    SUM(TotalOnHandQty) AS [on_hand_inventory_qty]
FROM [dw].[InventorySnapshot]
Observation: <skipped>"""
    },
    {
        "question": "What is the net value of the total on-hand inventory?",
        "answer": """
Thought: I can use the query from example bank to get the net value of the total on-hand inventory.
Action: sql_db_query
Action Input:
SELECT SUM([TotalOnHandQty] * [StandardUnitCostBalUSDAmt]) AS [inventory_value]
FROM [dw].[InventorySnapshot]
Observation: <skipped>
"""
    },
]
