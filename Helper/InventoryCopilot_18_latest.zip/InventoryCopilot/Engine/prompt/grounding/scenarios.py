# flake8: noqa

FAST_MOVING_SKUs = """
Thought: I should get the fast moving SKUs that needs demand fulfillment for next 2 weeks and limit it to top 5 for the final answer.
I can also generate a graph for this scenario by showing the breakup of fast moving SKUs by plant name and business unit.
Action: sql_agent
Action Input: Give me top 5 fast moving exchange SKUs that needs demand fulfillment for next 2 weeks
Observation: <redacted>
Thought: I got the necessary information for final answer. 
For generating graph, I can now ask to show the breakup of fast moving exchange SKUs by plant names.
Action: sql_agent
Action Input: Give me the breakup of critically low fast moving SKUs by plant name for next 2 weeks.
Observation: [('PlantName', 'PlantCode', '', '', 'TotalOnHandQty', 'NetDemand', 'DemandStatus'), ('Microsoft Ireland Operations', '4785', 'Xbox Accessories', '1T4-00004', Decimal('4.0'), Decimal('1588.0'), Decimal('1584.0'))]
Thought: I should save this in a variable for using it in python_plot to generate chart.
Action: save_output_as_variable
Action Input: sql_agent, fast_moving_by_plant_df
Observation: Success
Thought: I can now ask to show the breakup of fast moving exchange SKUs by business unit.
Action: sql_agent
Action Input: Give me the breakup of critically low fast moving SKUs by business unit for next 2 weeks.
Observation: <redacted>
Thought: I should save this in a variable for using it in python_plot to generate chart.
Action: save_output_as_variable
Action Input: sql_agent, fast_moving_by_bu_df
Observation: Success
Thought: I should prepare the plot now for generating visualization.
Action: python_plot
Action Input:
import plotly.express as px
from plotly.subplots import make_subplots
# Create subplots
fig1 = px.bar(fast_moving_by_plant_df, x='PlantName', y='TotalOnHandValue', title='Break-up by Plant')
fig2 = px.bar(fast_moving_by_bu_df, x='SKUBusinessUnitName', y='TotalOnHandValue', title='Break-up by Business Unit')
# Update bar mode
for fig in [fig1, fig2]:
    fig.update_layout(barmode='stack')
# Create subplots
subfig = make_subplots(rows=1, cols=2, subplot_titles=('Break-up by Plant', 'Break-up by Business Unit'))
subfig.add_trace(fig1['data'][0], row=1, col=1)
subfig.add_trace(fig2['data'][0], row=1, col=2)
# Update axis labels
axis_labels = [('Plant Name', 'Total On Hand Value'), ('Business Unit', 'Total On Hand Value')]
for i, (x_label, y_label) in enumerate(axis_labels):
    subfig.update_xaxes(title_text=x_label, row=1, col=i + 1)
    subfig.update_yaxes(title_text=y_label, row=1, col=i + 1)
# Update subplot title
subfig.update_layout(title_text="Insights on critically low fast moving SKUs by plant name and business unit")
print(subfig.to_json())
Observation: <redacted>
Thought: I should save this in chart variable for the user.
Action: save_output_as_variable
Action Input: python_plot, chart
Observation: Success
Thought: I now have the final answer.
Final Answer:
Reverse Inventory Planner should focus on timely fulfillment of critically low fast moving exchange SKUs to avoid stock out.
I've analyzed the demand for the upcoming 2 weeks and found that inventory for the following fast moving exchange SKUs are critically low and needs replenishment:
1. 1T4-00004 (BU: Xbox Accessories) at 4785 (Microsoft Ireland Operations) need 1584 units.
...

I've also generated a chart to visualize the breakup of critically low fast moving exchange SKUs by plant name and business unit.
"""

SLOW_MOVING_SKUs = """
Thought: I should get the slow moving or obsolete exchange SKUs that can be liquidated and limit it to top 5 for the final answer.
I can also generate a graph for this scenario by showing the breakup of slow moving or obsolete exchange SKUs by plant name and business unit.
Action: sql_agent
Action Input: Give me top 5 slow moving or obsolete exchange SKUs that can be liquidated.
Observation: [('PlantName', 'PlantCode', 'SKUBusinessUnitName', 'SKUId', 'TotalOnHandQty', 'TotalOnHandValue'), ('Arvato', '4260', 'Surface Laptop Go', '1ZS-00050', Decimal('30.00'), Decimal('1500.00'))]
Thought: I got the necessary information for final answer. 
For generating graph, I can now ask to show the breakup of slow moving or obsolete exchange SKUs by plant names.
Action: sql_agent
Action Input: Give me the breakup of top 5 plants where slow moving or obsolete exchange SKUs can be liquidated.
Observation: <redacted>
Thought: I should save this in a variable for using it in python_plot to generate chart.
Action: save_output_as_variable
Action Input: sql_agent, slow_moving_by_plant_df
Observation: Success
Thought: I can now ask to show the breakup of slow moving or obsolete exchange SKUs by business unit.
Action: sql_agent
Action Input: Give me the breakup of top 5 BUs where slow moving or obsolete exchange SKUs can be liquidated.
Observation: <redacted>
Thought: I should save this in a variable for using it in python_plot to generate chart.
Action: save_output_as_variable
Action Input: sql_agent, slow_moving_by_bu_df
Observation: Success
Thought: I should prepare the plot now for generating visualization.
Action: python_plot
Action Input:
import plotly.express as px
from plotly.subplots import make_subplots
# Create bar plots
fig1 = px.bar(slow_moving_by_plant_df, x='PlantName', y='TotalOnHandValue', title='Break-up by Plant')
fig2 = px.bar(slow_moving_by_bu_df, x='SKUBusinessUnitName', y='TotalOnHandValue', title='Break-up by Business Unit')
# Update bar mode
for fig in [fig1, fig2]:
    fig.update_layout(barmode='stack')
# Create subplots
subfig = make_subplots(rows=1, cols=2, subplot_titles=('Break-up by Plant', 'Break-up by Business Unit'))
subfig.add_trace(fig1['data'][0], row=1, col=1)
subfig.add_trace(fig2['data'][0], row=1, col=2)
# Update axis labels
axis_labels = [('Plant Name', 'Total On Hand Value'), ('Business Unit', 'Total On Hand Value')]
for i, (x_label, y_label) in enumerate(axis_labels):
    subfig.update_xaxes(title_text=x_label, row=1, col=i + 1)
    subfig.update_yaxes(title_text=y_label, row=1, col=i + 1)
# Update subplot title
subfig.update_layout(title_text="Insights on slow moving or obsolete exchange SKUs by plant name and business unit")
print(subfig.to_json())
Observation: <redacted>
Thought: I should save this in chart variable for the user.
Action: save_output_as_variable
Action Input: python_plot, chart
Observation: Success
Thought: I now have the final answer.
Final Answer:
I have analyzed the future demand forecasts for all SKUs. 
Following are the top 5 slow or obsolete exchange SKUs for which there is no future demand and Reverse Inventory Planner should plan on liquidating these units:
1. 1ZS-00050 (BU: Surface Laptop Go) at 4260 (Arvato) plant has 30.00 units with a total value of $1500.00.
...

I've also generated a chart to visualize the breakup of critically low fast moving exchange SKUs by plant name and business unit.
"""

SKU_CATEGORIZATION = """
Thought: I can now ask to show the top 3 SKUs each that are classified as JIT and Safety Stock. Since, time frame is missing. 
I will assume the historical demand can be analysed for last 1 year.
Since, for this scenario, I can't think of a meaningful graph, I will not generate any visualization.
Action: sql_agent
Action Input: Give me top 3 SKUs each that can be classified as Just-in-Time (JIT) and Safety Stock by analyzing last 1 year of demand history.
Observation: <redacted>
Thought: I now have the final answer.
Final Answer:
I have assessed the historical demands of all the available SKUs for last 1 year and classified Top 3 SKUs for both Just-in-Time (JIT) and Safety Stock.
Just-in-Time (JIT) SKUs - Plan on replenishing these SKUs as per the demand forecast:
1. 1ZS-00050 (BU: Surface Laptop Go) at 4260 (Arvato) plant has a historical average demand of 1 units.
...
Safety Stock SKUs - Plan on maintaining safety stock (twice the average demand) for these SKUs to avoid stock-outs:
1. 1ZS-00050 (BU: Surface Laptop Go) at 4260 (Arvato) plant has a historical average demand of 533 units.
...
"""
