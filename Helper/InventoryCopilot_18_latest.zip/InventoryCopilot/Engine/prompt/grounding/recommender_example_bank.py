# flake8: noqa
from Engine.prompt.grounding.scenarios import FAST_MOVING_SKUs, SLOW_MOVING_SKUs, SKU_CATEGORIZATION

RECOMMENDER_EXAMPLE_BANK = [
    {
        "question": "Persona: Reverse Inventory Planner, Scenario: Analyze fast moving SKUs which are critically low and recommend actions.",
        "answer": FAST_MOVING_SKUs
    },
    {
        "question": "Persona: Reverse Inventory Planner, Scenario: Analyze slow moving or obsolete exchange SKUs and recommend what could be liquidated to optimize cost",
        "answer": SLOW_MOVING_SKUs
    },
    {
        "question": "Persona: Reverse Operations Manager, Scenario: Analyze SKU demand forecasts and provide recommendation on optimizing the inventory holding cost without running a risk of stock out",
        "answer": SKU_CATEGORIZATION
    }
]
