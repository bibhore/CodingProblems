from Engine.prompt.grounding.scenarios import FAST_MOVING_SKUs, SLOW_MOVING_SKUs, SKU_CATEGORIZATION

CHAT_EXAMPLE_BANK = [
    {
        "session": """
question: Analyze fast moving SKUs which are critically low and recommend actions for Reverse Inventory Planner persona
answer: """ + FAST_MOVING_SKUs + """

question: Can you show me the recommendations only for APOC region?
answer:
Thought: Of the 3 regions (AOC, EOC, APOC) I know, user is asking the previous recommendation for filtered for 'APOC' region.
I can skip generating any graph for this question.
Action: sql_agent
Action Input: Give me top 5 fast moving exchange SKUs that needs demand fulfillment for next 2 weeks in APOC region
Observation: <skipped>
Thought: I now have the final answer
Final Answer:
Here are the recommendations customized for APOC region:
1. 1T4-00004 (BU: Xbox Accessories) at 4785 (Microsoft Ireland Operations) need 1584 units.
"""
    },
    {
        "session": """
question: Analyze slow moving or obsolete exchange SKUs and recommend what could be liquidated to optimize cost for Reverse Inventory Planner persona
answer: """ + SLOW_MOVING_SKUs + """
"""
    },
    {
        "session": """
question: Analyze SKU demand forecasts and provide recommendation on optimizing the inventory holding cost without running a risk of stock out for Reverse Operations Manager persona
answer: """ + SKU_CATEGORIZATION + """
"""
    }
]
