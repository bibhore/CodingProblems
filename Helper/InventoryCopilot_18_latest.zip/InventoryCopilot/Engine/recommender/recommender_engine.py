import os

from Engine.prompt.grounding.recommender_example_bank import RECOMMENDER_EXAMPLE_BANK
from Engine.prompt.recommender_prompt import RECOMMENDER_PREFIX, RECOMMENDER_SUFFIX, FORMAT_INSTRUCTIONS
from Engine.toolkit import SaveVariableTool, ExecutePythonCodeTool, SQLAgentTool
from Engine.chain import create_agent
from Engine.tools.exampleSelector import example_selector
from Engine.tools.python_client import PythonClient
from Engine.tools.sql_client import SQLClient
from langchain.chat_models import ChatOpenAI

#executor.run("Persona: Reverse Inventory Planner, Scenario: Optimize the planning for fast moving SKUs which are critically low.")

def recommender_agent(question: str,  db: SQLClient, example_count: int = 1):
    #db = SQLClient.from_config(schema='dw')
    db = db
    chat = ChatOpenAI(
        temperature=0.0,
        request_timeout=30,
        verbose=True,
        openai_api_key=os.getenv("OPENAI_API_KEY"),
        model_kwargs={'deployment_id': os.getenv("OPENAI_DEPLOYMENT_ENGINE")}
    )
    memory_store = {}
    python_client = PythonClient(_globals=memory_store)
    tools = [
        SaveVariableTool(python_client=python_client, db=db, memory_store=memory_store),
        ExecutePythonCodeTool(python_client=python_client, memory_store=memory_store),
        SQLAgentTool(db=db, llm=chat)
    ]
    # Get the examples list using example selector
    examples = example_selector(RECOMMENDER_EXAMPLE_BANK, question, k=example_count, question_key="question")
    executor = create_agent(
        chat,
        tools,
        verbose=True,
        prefix=RECOMMENDER_PREFIX,
        suffix=RECOMMENDER_SUFFIX,
        examples=examples,
        format_instructions=FORMAT_INSTRUCTIONS,
        template_format="jinja2",
        input_variables=["input", "agent_scratchpad"]
    )
    return {"response": executor.run(input=question), "chart": memory_store.get("chart", None)}
