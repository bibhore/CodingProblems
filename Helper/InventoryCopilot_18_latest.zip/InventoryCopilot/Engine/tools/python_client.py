import sys
from io import StringIO
from typing import Dict, Optional

from pydantic import BaseModel, Field


class PythonClient(BaseModel):
    """Simulates a standalone Python REPL."""

    globals: Optional[Dict] = Field(default_factory=dict, alias="_globals")
    locals: Optional[Dict] = Field(default_factory=dict, alias="_locals")
    last_output: Optional[str] = Field(default=None, alias="_last_output")

    def run(self, command: str) -> str:
        """Run command with own globals/locals and returns anything printed."""
        old_stdout = sys.stdout
        sys.stdout = mystdout = StringIO()
        try:
            exec(command, self.globals, self.locals)
            sys.stdout = old_stdout
            output = mystdout.getvalue()
            self.last_output = output
        except Exception as e:
            sys.stdout = old_stdout
            output = repr(e)
        return output
