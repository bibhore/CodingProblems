import os

from langchain.prompts.example_selector import SemanticSimilarityExampleSelector
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.prompts import FewShotPromptTemplate, PromptTemplate


def example_selector(examples, question: str, k: int = 2, question_key: str = "input"):
    selector = SemanticSimilarityExampleSelector.from_examples(
        # This is the list of examples available to select from.
        examples,
        # This is the embedding class used to produce embeddings which are used to measure semantic similarity.
        OpenAIEmbeddings(deployment=os.getenv("OPENAI_EMBEDDING_DEPLOYMENT_ENGINE")),
        # This is the VectorStore class that is used to store the embeddings and do a similarity search over.
        FAISS,
        # This is the number of examples to produce.
        k=k
    )
    return selector.select_examples({question_key: question})

if __name__ == '__main__':
    examples = [
        {"input": "happy", "output": "sad"},
        {"input": "tall", "output": "short"},
    ]
    question = "happy"
    example_count = 2
    question_key = "input"
    example_selector(examples, question, example_count, question_key)
