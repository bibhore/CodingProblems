from __future__ import annotations

import configparser
from sqlite3 import ProgrammingError
from typing import Optional, Dict, Any, List

import pandas as pd
from sqlalchemy import create_engine, text, select, Table, MetaData
from sqlalchemy.engine import Engine

from langchain import SQLDatabase
from langchain.utilities.sql_database import truncate_word
from sqlalchemy.engine import URL
import os

class SQLClient(SQLDatabase):
    _Dataframe = pd.DataFrame()

    def __init__(
            self,
            engine: Engine,
            schema: Optional[str] = None,
            metadata: Optional[MetaData] = None,
            ignore_tables: Optional[List[str]] = None,
            include_tables: Optional[List[str]] = None,
            sample_rows_in_table_info: int = 3,
            indexes_in_table_info: bool = False,
            custom_table_info: Optional[dict] = None,
            view_support: bool = False,
            max_string_length: int = 1000,
    ):
        super().__init__(
            engine=engine,
            schema=schema,
            metadata=metadata,
            ignore_tables=ignore_tables,
            include_tables=include_tables,
            sample_rows_in_table_info=sample_rows_in_table_info,
            indexes_in_table_info=indexes_in_table_info,
            custom_table_info=custom_table_info,
            view_support=view_support,
            max_string_length=max_string_length,
        )

    @classmethod
    def from_config(
            cls,
            config_file: str = './config/config.ini',
            engine_args: Optional[Dict[str, Any]] = None,
            **kwargs: Any,
    ) -> SQLClient:
        """Construct the DB engine from a ini file"""
        #config = configparser.ConfigParser()
        #config.read(config_file)
        # server_name = os.getenv('DB_SERVER_NAME')
        # database_name = os.getenv('DB_NAME')
        # username = os.getenv('DB_USERNAME')
        # password = os.getenv('DB_PASSWORD')
        # connection_string = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server_name};DATABASE={database_name};UID={username};PWD={password}"
        connection_string = "DRIVER={ODBC Driver 17 for SQL Server};SERVER=sql-maxscbi-dev.database.windows.net;DATABASE=inventorypoc;UID=maxsqladmin;PWD=R!1ainbow9!!"
        connection_url = URL.create("mssql+pyodbc", query={"odbc_connect": connection_string})

        # Construct the connection string
        # connection_string = f"mssql+pyodbc://{username}:{password}@{server_name}/{database_name}?driver=SQL+Server"
        # _engine_args = engine_args or {}
        # return cls(create_engine(connection_string, **_engine_args), **kwargs)
        # return cls(create_engine(connection_string, **(engine_args or {})), **kwargs, )
        _engine_args = engine_args or {}
        return cls(create_engine(connection_url, **_engine_args), **kwargs)

    def run(self, command: str, fetch: str = "all") -> str:
        result = ""
        with self._engine.begin() as connection:
            cursor = connection.execute(text(command))
            if cursor.returns_rows:
                result = cursor.fetchall()
        if len(result) > 0:
            column_names = result[0]._fields
            self._Dataframe = pd.DataFrame(result, columns=column_names)
            if isinstance(result, list):
                return str(
                    [tuple(name for name in column_names)] +
                    [
                        tuple(
                            truncate_word(c, length=self._max_string_length)
                            for c in r
                        )
                        for r in result
                    ]
                )

        return str(
            tuple(
                truncate_word(c, length=self._max_string_length) for c in result
            )
        )

    def _get_sample_rows(self, table: Table) -> str:
        # build the select command
        command = select(table).limit(self._sample_rows_in_table_info)

        # save the columns in string format
        columns_str = "\t".join([col.name for col in table.columns])

        try:
            # get the sample rows
            with self._engine.connect() as connection:
                sample_rows_result = connection.execute(command)  # type: ignore
                # shorten values in the sample rows
                sample_rows = list(
                    map(lambda ls: [str(i) for i in ls], sample_rows_result)
                )

            # save the sample rows in string format
            sample_rows_str = "\n".join(["\t".join(row) for row in sample_rows])

        # in some dialects when there are no rows in the table a
        # 'ProgrammingError' is returned
        except ProgrammingError:
            sample_rows_str = ""

        return (
            f"{self._sample_rows_in_table_info} rows from {table.name} table:\n"
            f"{columns_str}\n"
            f"{sample_rows_str}"
        )

    @property
    def dataframe(self):
        return self._Dataframe
