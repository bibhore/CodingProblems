import json

class InMemoryData:
    data_dict = {}
    listsize = 5
    
    # Method to add JSON data to the dictionary
    @classmethod
    def add_data(cls,key, json_data):
        if key not in cls.data_dict:
            cls.data_dict[key] = []
        cls.data_dict[key].append(json_data)
        if len(cls.data_dict[key]) > cls.listsize:
            cls.data_dict[key].pop(0)

 
    # Method to retrieve the list of JSON data for a given key
    @classmethod
    def get_data(cls,key):
        if key in cls.data_dict:
            return cls.data_dict[key]
        else:
            return []
        
