from langchain.prompts import StringPromptTemplate
from langchain import LLMChain, PromptTemplate
from typing import List, Union
import re
import os
from langchain.llms import AzureOpenAI
from langchain.chat_models import AzureChatOpenAI

class ContextualChain:
    # os.environ["OPENAI_API_TYPE"] = "azure"
    # os.environ["OPENAI_API_KEY"] = "3e7032c6ac9e4f64847ed831f6e9ad5d"
    # os.environ["OPENAI_API_BASE"] = "https://scriptazureopenai.openai.azure.com"
    # os.environ["OPENAI_API_VERSION"] = "2023-03-15-preview"
    # os.environ["OPENAI_API_TYPE"] = "azure"
    # os.environ["OPENAI_API_KEY"] = "23546b1af6524614b425f3aba3504b9b"
    # os.environ["OPENAI_API_BASE"] = "https://crewaoipoc.openai.azure.com/"
    # os.environ["OPENAI_API_VERSION"] = "2023-06-01-preview"

    template = """
    Given the conversation history so far and the question, your role is to create a semantically independent question. 
    History: {history}
    Question :{input}
    """
    prompt = PromptTemplate(
       template=template, input_variables=["input","history"]
    )

    # setup llm
    #llm = AzureChatOpenAI(deployment_name="compinsights-copilot", model_name="gpt-4-32k", temperature=0)

    def GetContextualQuestionFromChain (cls,question, history):
        llm =AzureChatOpenAI(deployment_name="insights", model_name="gpt-35-turbo", temperature=0)
        llm_chain = LLMChain(llm=llm, prompt=cls.prompt)
        contextualquestion =cls.llm_chain.run({"input":question, 'history':history})
        return contextualquestion